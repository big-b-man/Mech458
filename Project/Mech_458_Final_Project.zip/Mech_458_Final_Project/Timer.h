#ifndef TIMER_H
#define TIMER_H

/*timer.h header*/
//header file for timer.c

/* Subroutine headers */
void timer8MHz();
void mTimer(int count);
void uTimer(unsigned int count);

#endif /* TIMER_H */