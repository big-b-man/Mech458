#ifndef PWN_H
#define PWN_H

/*pwn.h header*/
//header file for pwn.c

/* Subroutine headers */
void pwm();
void pwmSet(unsigned char input);

#endif /* PWN_H */